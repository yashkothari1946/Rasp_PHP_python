<?php
$status3 = file_get_contents("buttonStatus3.txt");
echo $status3;
?>
