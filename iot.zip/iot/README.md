# Rasberry-pi-Smart-Home
Home Automation Using Rasberypi,

Hardwares :- 
==>> rasberry pi 2 or 3
==>> Relay

software:- 
==>> web host provider/ server (azure/aws)


