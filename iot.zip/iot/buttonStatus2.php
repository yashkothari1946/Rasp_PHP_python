<?php
$status2 = file_get_contents("buttonStatus2.txt");
echo $status2;
?>
