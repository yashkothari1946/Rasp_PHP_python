<?php
$status1 = file_get_contents("buttonStatus.txt");
$status2 = file_get_contents("buttonStatus2.txt");
$status3 = file_get_contents("buttonStatus3.txt");
echo $status1;
echo $status2;
echo $status3;
?>
